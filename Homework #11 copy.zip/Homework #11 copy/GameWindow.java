// Brian Boisjoli
// CS 110
// Final Homework: Game Interface Window

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class GameWindow extends JFrame
{
   public GameWindow()
   {
      // Set background color
      getContentPane().setBackground(Color.BLUE);
      
      // Set title name
      setTitle("War");
      
      // Set window size
      setLayout(new BorderLayout(200,100));
      
      //Set exit
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      // Create all the panels
      JPanel north = new JPanel();
      JPanel south = new JPanel();
      JPanel east = new JPanel();
      JPanel west = new JPanel();
      JPanel center = new JPanel();
      
      // Create the title and set font, color, and size
      JLabel title = new JLabel("War");
      title.setFont(new Font("SansSerif", Font.BOLD, 60));
      title.setForeground(Color.white);
      
      // Set the header/footer/center color
      north.setBackground(Color.black);
      south.setBackground(Color.black);
      center.setBackground(Color.black);
      
      // Create the flip button
      JButton flip = new JButton("Flip");
      
      // Create the war button and background
      JButton war = new JButton("War");
      war.setBackground(Color.blue);
      
      // Display each player's points
      JLabel points1 = new JLabel("Player One's Points: ");
      points1.setFont(new Font("SansSerif", Font.BOLD, 20));  
      
      // Display each player's points
      JLabel points2 = new JLabel("Player Two's Points: ");
      points2.setFont(new Font("SansSerif", Font.BOLD, 20));
      
      // Set the color of the players scores
      points1.setForeground(Color.white);
      points2.setForeground(Color.white);
      
      // Button for the exit and display winner
      JButton close = new JButton("End Game"); //Image for player 1 deck in West
      ImageIcon backW = new ImageIcon("back.jpg");
      JLabel backWest = new JLabel(backW);
      
      // Image for player 2 deck in East
      ImageIcon backE = new ImageIcon("back.jpg");
      JLabel backEast = new JLabel(backE);
       
      // Create north panel 
      north.add(title);
      
      // Create south panel
      south.add(points1);
      south.add(close);
      south.add(points2);
      
      // Create west panel
      west.add(backWest);
      
      // Create east panel
      east.add(backEast);
      
      // Create center panel
      center.add(flip);
      center.add(war);
      
      // Add all panels
      add(north, BorderLayout.NORTH);
      add(south, BorderLayout.SOUTH);
      add(center, BorderLayout.CENTER);
      add(west, BorderLayout.WEST);
      add(east, BorderLayout.EAST);
      
      // Pack and display the window
      pack();
      
      setVisible(true);
      
      // Make sure close button closes
      close.addActionListener(new CloseListener());
      
      flip.addActionListener(new FlipListener());
            
   }
   
   private class FlipListener implements ActionListener
   {
      public void actionPerformed (ActionEvent e)
      {
         // Create JLabels
         JPanel center = new JPanel();
         JPanel north = new JPanel();

         add(center, BorderLayout.CENTER);
         add(north, BorderLayout.NORTH);
         
         // Create an instance of the Card class
         Deck deck = new Deck();
         
         // Shuffle the deck
         deck.shuffle();
         
         // Display each player's points
         JLabel card1 = new JLabel(deck.dealCard().toString());
         card1.setFont(new Font("SansSerif", Font.BOLD, 10));
         card1.setForeground(Color.white);
         
         north.add(card1);
      }
   }
        
   private class CloseListener implements ActionListener
   {
      public void actionPerformed (ActionEvent e)
      {
         //Display winner
         JOptionPane.showMessageDialog(null, "The winner is: ");
        
         //north.setBackground
         System.exit(0);
      }
   }           
}
// Brian Boisjoli
// CS110
// Final Homework: Game Program

public class Game
{
   public static void main(String[] args)
   {
      new GameWindow();
   }
}